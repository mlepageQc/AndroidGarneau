# -*- coding: utf-8 -*-

import webapp2
import logging
import traceback
import datetime
import json
import math

from google.appengine.ext import ndb
from google.appengine.ext import db

# Importation des modèles de données personnalisés.
from models import Utilisateur, Offre, Demande

def distance(origin, destination):
    lat1, lon1 = origin
    lat2, lon2 = destination
    radius = 6371 # km

    dlat = math.radians(lat2-lat1)
    dlon = math.radians(lon2-lon1)
    a = math.sin(dlat/2) * math.sin(dlat/2) + math.cos(math.radians(lat1)) \
        * math.cos(math.radians(lat2)) * math.sin(dlon/2) * math.sin(dlon/2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
    d = radius * c

    return d

def serialiser_pour_json(objet):
    """ Permet de sérialiser les dates et heures pour transformer
        un objet en JSON.

        Args:
            objet (obj): L'objet à sérialiser.

        Returns:
            obj : Si c'est une date et heure, retourne une version sérialisée
                  selon le format ISO (str); autrement, retourne l'objet
                  original non modifié.
        """
    if isinstance(objet, datetime.datetime):
        # Pour une date et heure, on retourne une chaîne
        # au format ISO (sans les millisecondes).
        return objet.replace(microsecond=0).isoformat()
    elif isinstance(objet, datetime.date):
        # Pour une date, on retourne une chaîne au format ISO.
        return objet.isoformat()
    else:
        # Pour les autres types, on retourne l'objet tel quel.
        return objet


class MainPageHandler(webapp2.RequestHandler):

    def get(self):
        # Permet de vérifier si le service Web est en fonction.
        # On pourrait utiliser cette page pour afficher de l'information
        # (au format HTML) sur le service Web REST.
        self.response.headers['Content-Type'] = 'text/plain; charset=utf-8'
        self.response.out.write('TP5 "Service Web avec' + 
                                'Google App Engine, Steve Bérubé et Maxime Lepage')


class ConnexionHandler(webapp2.RequestHandler):
    def post(self):
        try:
            dict_utilisateur = json.loads(self.request.body)
            cle = ndb.Key('Utilisateur', dict_utilisateur['username'])
            unUtilisateur = cle.get()
            if unUtilisateur.password == dict_utilisateur['password']:
                dict_util = unUtilisateur.to_dict()
                json_data = json.dumps(dict_util,
                                       default=serialiser_pour_json)
                
                self.response.set_status(200)
                self.response.headers['Content-Type'] = ('application/json;' + 
                                                         ' charset=utf-8')
                self.response.out.write(json_data) 
        except (db.BadValueError, ValueError, KeyError):
            logging.error('%s', traceback.format_exc())
            self.error(400)
        except Exception:
            logging.error('%s', traceback.format_exc())
            self.error(500)
                

class UtilisateurHandler(webapp2.RequestHandler):

    def post(self):
        try:            
            dict_utilisateur = json.loads(self.request.body)
            cle = ndb.Key('Utilisateur', dict_utilisateur['username'])
            unUtilisateur = cle.get()
            
            if unUtilisateur is None:
                status = 201
                unUtilisateur = Utilisateur(key=cle)
            else:
                status = 200
                
            unUtilisateur.username = dict_utilisateur['username']
            unUtilisateur.password = dict_utilisateur['password']
            unUtilisateur.adresse = dict_utilisateur['adresse']
            unUtilisateur.nom = dict_utilisateur['nom']
            unUtilisateur.prenom = dict_utilisateur['prenom']

            unUtilisateur.put()
            self.response.set_status(status)

        except (db.BadValueError, ValueError, KeyError):
            logging.error('%s', traceback.format_exc())
            self.error(400)

        except Exception:
            logging.error('%s', traceback.format_exc())
            self.error(500)

class OffreHandler(webapp2.RequestHandler):
    def post(self):
        try: 
            dict_offre = json.loads(self.request.body)
            unOffre = Offre()
            unOffre.titre = dict_offre['titre']
            unOffre.point_depart = dict_offre['point_depart']
            unOffre.point_arrive = dict_offre['point_arrive']
            unOffre.date = dict_offre['date']
            unOffre.heure = dict_offre['heure']
            unOffre.nb_place = dict_offre['nb_place']
            unOffre.username = dict_offre['username']       
            
            cle_offre = unOffre.put()
            self.response.set_status(201)
            
            self.response.headers['Location'] = (self.request.url + '/' +
                                                 str(cle_offre.id()))
            self.response.headers['Content-Type'] = ('application/json;' +
                                                     ' charset=utf-8')
            dict_offre_out = unOffre.to_dict()
            dict_offre_out['_id'] = cle_offre.id()
        
            
            json_data_post = json.dumps(dict_offre_out, default=serialiser_pour_json)
            
            self.response.out.write(json_data_post)
        except (db.BadValueError, ValueError, KeyError):
            logging.error('%s', traceback.format_exc())
            self.error(400)
        except Exception:
            logging.error('%s', traceback.format_exc())
            self.error(500)
              
    def get(self, username):
        try:
            list_offre = []
            list_offre = Offre.query()
            list_offre_final = []
            
            for offre in list_offre:
                
                if username is not offre.username:
                    if offre.nb_place > 0:               
                        
                        coord_depart_offre = offre.point_depart.split(',')
                        coord_arrive_offre = offre.point_arrive.split(',')                 

                        offre_depart_lat = float(coord_depart_offre[0])
                        offre_depart_lon = float(coord_depart_offre[1])
                        
                        offre_arrivee_lat = float(coord_arrive_offre[0])
                        offre_arrivee_lon = float(coord_arrive_offre[1])                   
                        
                        coord_depart_recherche = self.request.get("coordDepart").split(',')
                        coord_arrive_recherche = self.request.get("coordArrivee").split(',')
                        
                        recherche_depart_lat = float(coord_depart_recherche[0])
                        recherche_depart_lon = float(coord_depart_recherche[1])
                        
                        recherche_arrivee_lat = float(coord_arrive_recherche[0])
                        recherche_arrivee_lon = float(coord_arrive_recherche[1])
    
                                          
                        if distance((offre_depart_lat,offre_depart_lon),(recherche_depart_lat,recherche_depart_lon)) <= 3.5 and distance((offre_arrivee_lat,offre_arrivee_lon),(recherche_arrivee_lat,recherche_arrivee_lon)) <= 3.5:
                                            
                            date = self.request.get("date")
                            
                            if offre.date == date:
                                offre_dict = offre.to_dict()
                                offre_dict['_id'] = offre.key.id()
                                list_offre_final.append(offre_dict)
              
            json_data = json.dumps(list_offre_final,
                                               default=serialiser_pour_json)
            self.response.set_status(200)
            self.response.headers['Content-Type'] = ('application/json;' + 
                                                     ' charset=utf-8')
            self.response.out.write(json_data) 
            
        except (db.BadValueError, ValueError, KeyError):
            logging.error('%s', traceback.format_exc())
            self.error(400)

        except Exception:
            logging.error('%s', traceback.format_exc())
            self.error(500)
    
    def put(self, _id):
        try:
            cle = ndb.Key('Offre', long(_id))
            offre = cle.get()
            
            if offre is None:
                status = 201
                offre = Offre(key=cle)
            else:
                status = 200
                
            offre_dict_in = json.loads(self.request.body)
            
            offre.titre = offre_dict_in['titre']
            offre.point_depart = offre_dict_in['point_depart']
            offre.point_arrive = offre_dict_in['point_arrive']
            offre.date = offre_dict_in['date']
            offre.heure = offre_dict_in['heure']
            offre.nb_place = offre_dict_in['nb_place']
            
            offre.put()
            
            self.response.set_status(status)
            offre_dict = offre.to_dict()
            offre_dict['id_offre'] = offre.key.id()
            offre_json = json.dumps(offre_dict, default=serialiser_pour_json)
            self.response.headers['Content-Type'] = ('application/json;' +
                                                     ' charset=utf-8')
            self.response.out.write(offre_json)
            
        except (db.BadValueError, ValueError, KeyError):
            logging.error('%s', traceback.format_exc())
            # Bad Request.
            self.error(400)

        # Exceptions graves lors de l'exécution du code
        # (non liées à la requête).
        except Exception:
            logging.error('%s', traceback.format_exc())
            # Internal Server Error.
            self.error(500)
            
    def delete(self, _id):
        try:
            if _id is not None:
                cle = ndb.Key('Offre', long(_id))              
                offre = cle.get()
                
                list_demandes = []
                list_demandes = Demande.query()
                
                for demande in list_demandes:
                    if long(demande.idOffre) == (long(_id)):
                        cle_demande = ndb.Key('Demande', demande.key.id())
                        demande.key.delete()
                        cle_demande.delete()
                                
                offre.key.delete()
                cle.delete()
            
                self.response.set_status(204)
                
        except (db.BadValueError, ValueError, KeyError):
            logging.error('%s', traceback.format_exc())
            self.error(400)

        except Exception:
            logging.error('%s', traceback.format_exc())
            self.error(500)
            

class DemandeHandler(webapp2.RequestHandler):
    def delete(self, _id, accepter):
        try:
            if _id is not None:
                cle = ndb.Key('Demande', long(_id))
                demande = Demande()              
                demande = cle.get()
                
                if accepter is not None:
                    cle_offre = ndb.Key('Offre', long(demande.idOffre))
                    offre = Offre()
                    offre = cle_offre.get()
                    
                    offre.passagers.append(demande.username)
                    offre.nb_place = offre.nb_place - 1
                    offre.put()
                            
                demande.key.delete()
                cle.delete()
            
                self.response.set_status(204)
                
        except (db.BadValueError, ValueError, KeyError):
            logging.error('%s', traceback.format_exc())
            self.error(400)

        except Exception:
            logging.error('%s', traceback.format_exc())
            self.error(500)
    
    def get(self, username):
        try:
            list_demande = []
            list_demande = Demande.query()
            list_demande_final = []
            
            offre = Offre()
            
            for demande in list_demande:                
                cle = ndb.Key('Offre', long(demande.idOffre))        
                offre = cle.get() 
                                                   
                if offre.username == username:
                    
                    demande_dict = demande.to_dict()
                    demande_dict['_id'] = demande.key.id()
                    list_demande_final.append(demande_dict)

            json_data = json.dumps(list_demande_final,
                                               default=serialiser_pour_json)
            self.response.set_status(200)
            self.response.headers['Content-Type'] = ('application/json;' + 
                                                     ' charset=utf-8')
            self.response.out.write(json_data)
            
        except (db.BadValueError, ValueError, KeyError):
            logging.error('%s', traceback.format_exc())
            self.error(400)

        except Exception:
            logging.error('%s', traceback.format_exc())
            self.error(500)
            
    def post(self):
        try: 
            dict_demande = json.loads(self.request.body)
            uneDemande = Demande()
            uneDemande.idOffre = dict_demande['idOffre']
            uneDemande.username = dict_demande['username']
            uneDemande.titre = dict_demande['titre']  
            uneDemande.notifie = False;  
            
            cle_demande= uneDemande.put()
            self.response.set_status(201)
            
            self.response.headers['Location'] = (self.request.url + '/' +
                                                 str(cle_demande.id()))
            self.response.headers['Content-Type'] = ('application/json;' +
                                                     ' charset=utf-8')
            dict_demande_out = uneDemande.to_dict()
            dict_demande_out['_id'] = cle_demande.id()
        
            json_data_post = json.dumps(dict_demande_out, default=serialiser_pour_json)
            self.response.out.write(json_data_post) 
            
        except (db.BadValueError, ValueError, KeyError):
            logging.error('%s', traceback.format_exc())
            self.error(400)

        except Exception:
            logging.error('%s', traceback.format_exc())
            self.error(500)
    
    def put(self, _id):
        try:
            if _id is not None:
                
                demande = Demande()
                cle = ndb.Key('Demande', long(_id))
                demande = cle.get()            
                demande.notifie = True           
                demande.put()
                
        except (db.BadValueError, ValueError, KeyError):
            logging.error('%s', traceback.format_exc())
            self.error(400)

        except Exception:
            logging.error('%s', traceback.format_exc())
            self.error(500)     
                                                                   
app = webapp2.WSGIApplication(
    [
        webapp2.Route(r'/',
                      handler=MainPageHandler,
                      methods=['GET']),
        webapp2.Route(r'/connexion', handler=ConnexionHandler,
                      methods=['POST']),
        webapp2.Route(r'/utilisateur', handler=UtilisateurHandler,
                      methods=['POST']),
        webapp2.Route(r'/offre', handler=OffreHandler,
                      methods=['POST']),
        webapp2.Route(r'/offre/<username>', handler=OffreHandler,
                      methods=['GET']),
        webapp2.Route(r'/offre/<_id>', handler=OffreHandler,
                      methods=['PUT', 'DELETE']),
        webapp2.Route(r'/demande/<username>', handler=DemandeHandler,
                      methods=['GET']),
        webapp2.Route(r'/demande/<_id>/<accepter>', handler=DemandeHandler,
                      methods=['DELETE']),
        webapp2.Route(r'/demande', handler=DemandeHandler,
                      methods=['POST']),
     webapp2.Route(r'/demande/<_id>', handler=DemandeHandler,
                      methods=['PUT']),
    ],
    debug=True)
