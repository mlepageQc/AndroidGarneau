# -*- coding: utf-8 -*-

from google.appengine.ext import ndb

class Utilisateur(ndb.Model):
    username = ndb.StringProperty(required=True)
    password = ndb.StringProperty(required=True)
    adresse = ndb.StringProperty(required=True)
    nom = ndb.StringProperty(required=True)
    prenom = ndb.StringProperty(required=True)

class Offre(ndb.Model):
    passagers = ndb.StringProperty(repeated=True)
    titre = ndb.StringProperty(required=True)
    point_depart = ndb.StringProperty(required=True)
    point_arrive = ndb.StringProperty(required=True)
    date = ndb.StringProperty(required=True)
    heure = ndb.StringProperty(required=True)
    nb_place = ndb.IntegerProperty(required=True)
    username = ndb.StringProperty(required=True)

class Demande(ndb.Model):
    idOffre = ndb.StringProperty(required=True)
    username = ndb.StringProperty(required=True)
    titre = ndb.StringProperty(required=True)
    notifie = ndb.BooleanProperty(required=True)